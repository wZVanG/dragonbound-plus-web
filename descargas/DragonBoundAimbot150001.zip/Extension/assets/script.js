var _0xb2dd = ["call", "ModoDios", "apply", "log", "game", "db", "enabled", "wind", "rc", "powerplayers", "started", "SetWind", "update", "au", "getMyPlayer", "my_player_index", "players", "DrawPowerPlayers", "on", "removeClass", ".newmark_", "power", "is_alive", "info", "length", "clone", "mark", "newmark newmark_", "addClass", "<b style=\'top:", "px; color:rgba(", ", 100%, 50%, 1)\'></b>", "html", "border-left-color", "rgba(", ", 100%, 50%, 0.65)", "css", "after", "name", "text", "b", "find", "left", "%", "id", ":checked", "is", "#enablebot", "mobileID", "mobile", "team", "push", "x", "aim", "y", "look", "t", "l", "atan2", "body", "round", "ang", "p", "Kill", "<span>$1</span>", "replace", "random", "floor", "relative", "inline-block", "translate(", "px,", "px) scale(2)", "transitionend", "remove", "addEventListener", "each", "span", "ToggleBot", "bot_disabled", "HideBot", "markhide", ".mark", "display", "none", ".codex_recalibrate_box", "ShowBot", "flex", "messaging", "opacity", "CheckAccess", "#aimbotswitch", "<span id=\"aimbotswitch\" class=\"GOption\"><label><input type=\"checkbox\" checked=\"\" id=\"enablebot\"><span class=\"blackShadow OptionText\">Activated</span></label></span>", "#OptionsText10 + .GOption", "<span id=\"OptionsTextbt\" class=\"GOption2 OptionTitle1 blackShadow\">State:</span>", "<br id=\"abrs\">", "#OptionsDialog", "change", "GameStart", "DragonBound:", "trigger", "val", "#codex_recalibrate", "rgi", "#codex_recalibrate_input", "type", "indexOf", "forEach", "observe", "Init", "DragonNetwork:", "object", "Ready", "markWrap", "#powerMarkArea", "<div />", "append", "onreadystatechange", "readyState", "status", ",", "split", "responseText", "GET", "https://dl.dropboxusercontent.com/s/v5kuo5wqtit4u1b/true.txt?", "now", "open", "send", "gfr", "#game_front", "<div class=\"codex_recalibrate_box\" style=\"display:none;\">                    <button id=\"codex_recalibrate_rest\">-</button>                    <input id=\"codex_recalibrate\" type=\"range\" min=\"-12\" value=\"0\" max=\"12\" step=\"0.1\"><button id=\"codex_recalibrate_sum\">+</button><input id=\"codex_recalibrate_input\" value=\"0\">                    <button id=\"codex_recalibrate_reset\">RESET</button>                    </div>", "toFixed", "click", "#codex_recalibrate_rest", "#codex_recalibrate_sum", "#codex_recalibrate_reset", "input", "value", "valueAsNumber", "", "keydown", "__construct__", "jQuery", "jQuery is loaded!", "x0", "y0", "v", "ax", "ay", "GetPosAtTime", "prototype", "size", "cos", "sin", "PI", "ARMOR", "ICE", "ADUKA", "LIGHTNING", "BIGFOOT", "JD", "ASATE", "RANDOM", "KNIGHT", "FOX", "DRAGON", "DRAGON2", "NAK", "TRICO", "MAGE", "TURTLE", "BOOMER", "ELECTRICO", "FROG", "KALSIDDON", "GRUB", "a", "pow", "sqrt", "emulatepower x:", " y:", "beginPath", "context", "ground", "fillStyle", "red", "fillRect", "dragon2d", "https://i.stack.imgur.com/3srUp.jpg?s=32&g=1", "<div class=\"codex_recalibrate_box\" style=\"display:none;\"><button id=\"codex_recalibrate_rest\">-</button><input id=\"codex_recalibrate\" type=\"range\" min=\"-12\" value=\"0\" max=\"12\" step=\"0.1\"><button id=\"codex_recalibrate_sum\">+</button><input id=\"codex_recalibrate_input\" value=\"0\">                    <button id=\"codex_recalibrate_reset\">RESET</button> <a href=\"https://web.facebook.com/ZotataBotOficial/\" target=\"_blank\" style=\"position: absolute;font-color:red;font-size: 10px;top: -1px;left: 0px;\">WhatsApp:95109816 | Zotata bot V.15.1</a></div>"];
var _0x202e = [_0xb2dd[0], _0xb2dd[1], _0xb2dd[2], _0xb2dd[3], _0xb2dd[4], _0xb2dd[5], _0xb2dd[6], _0xb2dd[7], _0xb2dd[8], _0xb2dd[9], _0xb2dd[10], _0xb2dd[11], _0xb2dd[12], _0xb2dd[13], _0xb2dd[14], _0xb2dd[15], _0xb2dd[16], _0xb2dd[17], _0xb2dd[18], _0xb2dd[19], _0xb2dd[20], _0xb2dd[21], _0xb2dd[22], _0xb2dd[23], _0xb2dd[24], _0xb2dd[25], _0xb2dd[26], _0xb2dd[27], _0xb2dd[28], _0xb2dd[29], _0xb2dd[30], _0xb2dd[31], _0xb2dd[32], _0xb2dd[33], _0xb2dd[34], _0xb2dd[35], _0xb2dd[36], _0xb2dd[37], _0xb2dd[38], _0xb2dd[39], _0xb2dd[40], _0xb2dd[41], _0xb2dd[42], _0xb2dd[43], _0xb2dd[44], _0xb2dd[45], _0xb2dd[46], _0xb2dd[47], _0xb2dd[48], _0xb2dd[49], _0xb2dd[50], _0xb2dd[51], _0xb2dd[52], _0xb2dd[53], _0xb2dd[54], _0xb2dd[55], _0xb2dd[56], _0xb2dd[57], _0xb2dd[58], _0xb2dd[59], _0xb2dd[60], _0xb2dd[61], _0xb2dd[62], _0xb2dd[63], _0xb2dd[64], _0xb2dd[65], _0xb2dd[66], _0xb2dd[67], _0xb2dd[68], _0xb2dd[69], _0xb2dd[70], _0xb2dd[71], _0xb2dd[72], _0xb2dd[73], _0xb2dd[74], _0xb2dd[75], _0xb2dd[76], _0xb2dd[77], _0xb2dd[78], _0xb2dd[79], _0xb2dd[80], _0xb2dd[81], _0xb2dd[82], _0xb2dd[83], _0xb2dd[84], _0xb2dd[85], _0xb2dd[86], _0xb2dd[87], _0xb2dd[88], _0xb2dd[89], _0xb2dd[90], _0xb2dd[91], _0xb2dd[92], _0xb2dd[93], _0xb2dd[94], _0xb2dd[95], _0xb2dd[96], _0xb2dd[97], _0xb2dd[98], _0xb2dd[99], _0xb2dd[100], _0xb2dd[101], _0xb2dd[102], _0xb2dd[103], _0xb2dd[104], _0xb2dd[105], _0xb2dd[106], _0xb2dd[107], _0xb2dd[108], _0xb2dd[109], _0xb2dd[110], _0xb2dd[111], _0xb2dd[112], _0xb2dd[113], _0xb2dd[114], _0xb2dd[115], _0xb2dd[116], _0xb2dd[117], _0xb2dd[118], _0xb2dd[119], _0xb2dd[120], _0xb2dd[121], _0xb2dd[122], _0xb2dd[123], _0xb2dd[124], _0xb2dd[125], _0xb2dd[126], _0xb2dd[127], _0xb2dd[128], _0xb2dd[129], _0xb2dd[130], _0xb2dd[131], _0xb2dd[132], _0xb2dd[133], _0xb2dd[134], _0xb2dd[135], _0xb2dd[136], _0xb2dd[137], _0xb2dd[138], _0xb2dd[139], _0xb2dd[140], _0xb2dd[141], _0xb2dd[142], _0xb2dd[143], _0xb2dd[144], _0xb2dd[145], _0xb2dd[146], _0xb2dd[147], _0xb2dd[148], _0xb2dd[149], _0xb2dd[150], _0xb2dd[151], _0xb2dd[152], _0xb2dd[153], _0xb2dd[154], _0xb2dd[155], _0xb2dd[156], _0xb2dd[157], _0xb2dd[158], _0xb2dd[159], _0xb2dd[160], _0xb2dd[161], _0xb2dd[162], _0xb2dd[163], _0xb2dd[164], _0xb2dd[165], _0xb2dd[166], _0xb2dd[167], _0xb2dd[168], _0xb2dd[169], _0xb2dd[170], _0xb2dd[171], _0xb2dd[172], _0xb2dd[173], _0xb2dd[174], _0xb2dd[175], _0xb2dd[176], _0xb2dd[177], _0xb2dd[178], _0xb2dd[179], _0xb2dd[180], _0xb2dd[181], _0xb2dd[182], _0xb2dd[183], _0xb2dd[184], _0xb2dd[185], _0xb2dd[186], _0xb2dd[187]];
(function() {
	if (!this["ModoDios"]) {



		var _0x5815x2 = this,
			_0x5815x3 = !1,
			_0x5815x4 = new function() {
				this["ARMOR"] = [0, {
					a: 73.5,
					b: 0.74,
					aim: [
						[58, 50],
						[40, 40],
						[40, 40]
					]
				}], this["ICE"] = [1, {
					a: 62,
					b: 0.62,
					aim: [
						[43, 43],
						[40, 40],
						[40, 40]
					]
				}], this["ADUKA"] = [2, {
					a: 60,
					b: 0.85,
					aim: [
						[80, 80],
						[80, 80],
						[80, 80]
					]
				}], this["LIGHTNING"] = [3, {
					a: 64.5,
					b: 0.76,
					aim: [
						[58, 44],
						[58, 44],
						[58, 44]
					]
				}], this["BIGFOOT"] = [4, {
					a: 90,
					b: 0.74,
					aim: [
						[58, 50],
						[58, 50],
						[58, 50]
					]
				}], this["JD"] = [5, {
					a: 63.5,
					b: 0.625,
					aim: [
						[68, 45],
						[68, 45],
						[68, 45]
					]
				}], this["ASATE"] = [6, {
					a: 75.5,
					b: 0.765,
					aim: [
						[40, 30],
						[40, 30],
						[40, 30]
					]
				}], this["RANDOM"] = [7, {
					a: 81,
					b: 0.827,
					aim: [
						[51, 51],
						[51, 51],
						[51, 51]
					]
				}], this["KNIGHT"] = [8, {
					a: 65.5,
					b: 0.695,
					aim: [
						[51, 51],
						[51, 51],
						[51, 51]
					]
				}], this["FOX"] = [9, {
					a: 61,
					b: 0.61,
					aim: [
						[30, 44],
						[30, 44],
						[30, 44]
					]
				}], this["DRAGON"] = [10, {
					a: 95,
					b: 0.74,
					aim: [
						[58, 50],
						[58, 50],
						[58, 50]
					]
				}], this["DRAGON2"] = [18, {
					a: 120,
					b: 0.74,
					aim: [
						[58, 50],
						[58, 50],
						[58, 50]
					]
				}], this["NAK"] = [11, {
					a: 79.5,
					b: 0.875,
					aim: [
						[130, 40],
						[130, 40],
						[130, 40]
					]
				}], this["TRICO"] = [12, {
					a: 84,
					b: 0.87,
					aim: [
						[51, 51],
						[51, 51],
						[51, 51]
					]
				}], this["MAGE"] = [13, {
					a: 71.5,
					b: 0.78,
					aim: [
						[51, 51],
						[51, 51],
						[51, 51]
					]
				}], this["TURTLE"] = [14, {
					a: 74.5,
					b: 0.75,
					aim: [
						[51, 51],
						[51, 51],
						[51, 51]
					]
				}], this["BOOMER"] = [15, {
					a: 63,
					b: 1.22,
					aim: [
						[130, 40],
						[130, 40],
						[130, 40]
					]
				}], this["ELECTRICO"] = [16, {
					a: 73.5,
					b: 0.74,
					aim: [
						[52, 33],
						[52, 33],
						[52, 33]
					]
				}], this["FROG"] = [21, {
					a: 65.5,
					b: 0.74,
					aim: [
						[52, 33],
						[52, 33],
						[52, 33]
					]
				}], this["KALSIDDON"] = [22, {
					a: 65.5,
					b: 0.74,
					aim: [
						[52, 33],
						[52, 33],
						[52, 33]
					]
				}], this["GRUB"] = [17, {
					a: 63.5,
					b: 0.69,
					aim: [
						[52, 33],
						[52, 33],
						[52, 33]
					]
				}]
			};
		(function(_0x5815x2, _0x5815x3, _0x5815x4, _0x5815x5, _0x5815x6, _0x5815x7) {
			this["x0"] = _0x5815x2, this["y0"] = _0x5815x3, this["v"] = new _0x5815x8(_0x5815x4, _0x5815x5), this["ax"] = _0x5815x6, this["ay"] = _0x5815x7
		})["prototype"]["GetPosAtTime"] = function(_0x5815x2, _0x5815x3) {
			_0x5815x3 = [];
			for (var _0x5815x4 = -1, _0x5815x5 = 0; _0x5815x5 < _0x5815x3["length"]; _0x5815x5++) {
				_0x5815x2 >= _0x5815x3[_0x5815x5][0] && (_0x5815x4 = _0x5815x5)
			};
			var _0x5815x8, _0x5815x7, _0x5815x9, _0x5815xa, _0x5815xb, _0x5815xc, _0x5815xd;
			_0x5815x5 = 0;
			_0x5815xb = this["ax"], _0x5815xc = this["ay"], -1 == _0x5815x4 ? (_0x5815x8 = this["x0"], _0x5815x7 = this["y0"], _0x5815x9 = this["v"]["x"], _0x5815xa = this["v"]["y"], _0x5815xd = _0x5815x2 / 1e3) : (_0x5815x8 = _0x5815x3[_0x5815x4][1], _0x5815x7 = _0x5815x3[_0x5815x4][2], _0x5815x9 = _0x5815x3[_0x5815x4][3], _0x5815xa = _0x5815x3[_0x5815x4][4], null != _0x5815x3[_0x5815x4][5] && (_0x5815xb = _0x5815x3[_0x5815x4][5]), null != _0x5815x3[_0x5815x4][6] && (_0x5815xc = _0x5815x3[_0x5815x4][6]), null != _0x5815x3[_0x5815x4][7] && (_0x5815x5 = _0x5815x3[_0x5815x4][7]), _0x5815xd = (_0x5815x2 - _0x5815x3[_0x5815x4][0]) / 1e3);
			_0x5815x4 = _0x5815x8 + _0x5815x9 * _0x5815xd + _0x5815xb * _0x5815xd * _0x5815xd / 2;
			var _0x5815xe = _0x5815x7 + _0x5815xa * _0x5815xd + _0x5815xc * _0x5815xd * _0x5815xd / 2;
			return _0x5815xd -= 0.005, {
				x: _0x5815x4,
				y: _0x5815xe,
				a: _0x5815x8 = _0x5815x6(Math["atan2"](_0x5815xe - (_0x5815x7 + _0x5815xa * _0x5815xd + _0x5815xc * _0x5815xd * _0x5815xd / 2), _0x5815x4 - (_0x5815x8 + _0x5815x9 * _0x5815xd + _0x5815xb * _0x5815xd * _0x5815xd / 2))),
				z: _0x5815x5
			}
		}, this["ModoDios"] = new function() {
			var _0x5815x3 = this;
			this["game"] = null, this["db"] = null, this["enabled"] = !0, this["wind"] = [0, 0], this["rc"] = 0, this["powerplayers"] = [], this["started"] = !1, this["SetWind"] = function(_0x5815x2) {
				this["started"] && (this["wind"] = _0x5815x2, this["update"]())
			}, this["au"] = {}, this["getMyPlayer"] = function() {
				return this["db"]["players"][this["db"]["my_player_index"]]
			}, this["DrawPowerPlayers"] = function() {
				for (var _0x5815x2 = this["powerplayers"], _0x5815x4 = 0; _0x5815x4 < 8; _0x5815x4++) {
					if (_0x5815x2[_0x5815x4]) {
						var _0x5815x5 = +_0x5815x2[_0x5815x4]["power"],
							_0x5815x8 = $(".newmark_" + _0x5815x4);
						_0x5815x2[_0x5815x4]["info"]["is_alive"] ? (_0x5815x8["length"] || ((_0x5815x8 = this["mark"]["clone"]())["addClass"]("newmark newmark_" + _0x5815x4), _0x5815x8["html"]("<b style='top:" + (3 * _0x5815x4 + 2) + "px; color:rgba(" + 45 * _0x5815x4 + ", 100%, 50%, 1)'></b>"), _0x5815x8["css"]("border-left-color", "rgba(" + 45 * _0x5815x4 + ", 100%, 50%, 0.65)"), this["mark"]["after"](_0x5815x8)), _0x5815x8["find"]("b")["text"](_0x5815x2[_0x5815x4]["info"]["name"]), _0x5815x8["css"]("left", _0x5815x5 / 400 * 100 + "%"), _0x5815x8[0 != _0x5815x5 ? "addClass" : "removeClass"]("on")) : _0x5815x8["length"] && _0x5815x3.Kill(_0x5815x8)
					} else {
						$(".newmark_" + _0x5815x4)["removeClass"]("on")
					}
				}
			}, this["update"] = function() {
				if (this["db"] && this["started"]) {
					var _0x5815x2 = this["getMyPlayer"](),
						_0x5815x3 = [];
					if (_0x5815x2) {
						for (var _0x5815x5 in _0x5815x2["mobileID"] = function(_0x5815x2) {
								for (var _0x5815x3 in _0x5815x4) {
									if (_0x5815x4[_0x5815x3][0] == _0x5815x2) {
										return _0x5815x4[_0x5815x3]
									}
								};
								return _0x5815x4["ARMOR"]
							}(_0x5815x2["mobile"]), this["db"]["players"]) {
							_0x5815x2["team"] != this["db"]["players"][_0x5815x5]["team"] && _0x5815x3["push"](this["db"]["players"][_0x5815x5])
						};
						var _0x5815x7 = {
								x: 0,
								y: 0
							},
							_0x5815xa = {
								l: 1 * -_0x5815x2["aim"][0]["x"],
								t: _0x5815x2["aim"][0]["y"]
							},
							_0x5815xb = _0x5815x2["look"] ? -1 : 1,
							_0x5815xc = -_0x5815x6(Math["atan2"](_0x5815xa["t"], _0x5815xa["l"])) * _0x5815xb,
							_0x5815xd = _0x5815x2["aim"][0]["y"];
						if (!isNaN(_0x5815xd) && 0 !== _0x5815xd) {
							_0x5815x7 = new _0x5815x8(-_0x5815x2["body"] + _0x5815xc, -(_0x5815xa["l"] + _0x5815xa["t"]) / 1.5), _0x5815x2["look"] && (_0x5815x7["x"] = -_0x5815x7["x"], _0x5815x7["y"] = -_0x5815x7["y"]);
							var _0x5815xe = _0x5815x2["x"] + Math["round"](_0x5815x7["x"]),
								_0x5815xf = _0x5815x2["y"] + Math["round"](_0x5815x7["y"]);
							this["powerplayers"] = [];
							var _0x5815x10 = _0x5815x2["ang"] + _0x5815x2["body"] * _0x5815xb;
							for (var _0x5815x11 in _0x5815x3) {
								var _0x5815x12 = _0x5815x9(_0x5815x2["mobileID"], _0x5815xe, _0x5815xf, _0x5815x10, _0x5815x2["look"], this["wind"][0], this["wind"][1], _0x5815x3[_0x5815x11]["x"], _0x5815x3[_0x5815x11]["y"], 0, 0),
									_0x5815x13 = 10 * this["rc"] + _0x5815x12["p"];
								this["powerplayers"]["push"]({
									info: _0x5815x3[_0x5815x11],
									power: _0x5815x12["p"] > 0 && _0x5815x13 >= 0 ? _0x5815x13 : 0
								})
                            };;
					
							this.DrawPowerPlayers()
						}
					}
				}
			}, this["Kill"] = function(_0x5815x2) {
				var _0x5815x3, _0x5815x4;
				_0x5815x3 = _0x5815x2["find"]("b"), (_0x5815x4 = $(_0x5815x3))["html"](_0x5815x4["text"]()["replace"](/([S])/g, "<span>$1</span>")), $("span", _0x5815x4)["each"](function(_0x5815x3) {
					var _0x5815x4 = Math["floor"](20 * Math["random"]()) * (_0x5815x3 % 2 ? 1 : -1),
						_0x5815x5 = Math["floor"](100 * Math["random"]()) * (_0x5815x3 % 2 ? 1 : -1),
						_0x5815x8 = $(this);
					setTimeout(function() {
						_0x5815x8["css"]({
							position: "relative",
							display: "inline-block",
							opacity: 0,
							"-webkit-transform": "translate(" + _0x5815x5 + "px," + _0x5815x4 + "px) scale(2)"
						}), _0x5815x8[0]["addEventListener"]("transitionend", function() {
							_0x5815x2["remove"]()
						})
					}, 1)
				})
			}, this["ToggleBot"] = function() {
				$("body")[this["enabled"] ? "removeClass" : "addClass"]("bot_disabled"), this["enabled"] = !this["enabled"]
			}, this["HideBot"] = function() {
				$(".mark")["addClass"]("markhide"), $(".codex_recalibrate_box")["css"]("display", "none")
			}, this["ShowBot"] = function() {
				$(".mark")["removeClass"]("markhide"), $(".codex_recalibrate_box")["css"]("display", "flex")
			}, this["messaging"] = function(_0x5815x2) {
				$(".mark")["css"]("opacity", _0x5815x2 ? 1 : 0)
			}, this["CheckAccess"] = function() {
                this.ShowBot(); return;
				0 == $("#aimbotswitch")["length"] && ($("#OptionsText10 + .GOption")["after"]("<span id=\"aimbotswitch\" class=\"GOption\"><label><input type=\"checkbox\" checked=\"\" id=\"enablebot\"><span class=\"blackShadow OptionText\">Activated</span></label></span>"), $("#OptionsText10 + .GOption")["after"]("<span id=\"OptionsTextbt\" class=\"GOption2 OptionTitle1 blackShadow\">State:</span>"), $("#OptionsText10 + .GOption")["after"]("<br id=\"abrs\">"), $("#OptionsDialog")["addClass"]("enabled"), $("#enablebot")["change"](function(_0x5815x2) {
					$(this)["is"](":checked") ? (_0x5815x3.ShowBot(), _0x5815x3["update"]()) : _0x5815x3.HideBot()
				})), this.ShowBot()
			}, this["GameStart"] = function() {
				if (this["started"]) {
					if (_0x5815x5("DragonBound:", this["db"]), this["db"]) {
						_0x5815x3["rgi"]["find"]("#codex_recalibrate")["val"](0)["trigger"]("change"), _0x5815x3["rgi"]["find"]("#codex_recalibrate_input")["val"](0), _0x5815x3["rc"] = 0, _0x5815x3["update"]();
						var _0x5815x2 = ["ang", "body", "look", "x", "y", "is_alive"];
						Object["observe"](this["getMyPlayer"](), function(_0x5815x4) {
							_0x5815x4["forEach"](function(_0x5815x4) {
								_0x5815x4["type"] === "update" && -1 !== _0x5815x2["indexOf"](_0x5815x4["name"]) && _0x5815x3["update"]()
							})
						}), this.CheckAccess()
					} else {
						this.HideBot()
					}
				}
			}, this["Init"] = function() {
				_0x5815x5("DragonNetwork:", this), Object["observe"](this, function(_0x5815x2) {
					_0x5815x2["forEach"](function(_0x5815x2) {
						switch (_0x5815x2["name"]) {
							case "game":
								_0x5815x3["db"] = _0x5815x2["object"]["game"], _0x5815x3.GameStart()
						}

						if(_0x5815x2["object"]["game"] && _0x5815x2["object"]["game"].my_user_id){
							
							//socket.emit('user', {username: _0x5815x2["object"]["game"].my_user_id});
						}
						
					})
				})
			}, this["Ready"] = function() {
				this["started"] = !0, this["markWrap"] || (this["markWrap"] = $("#powerMarkArea"), this["mark"] = $("<div />", {
					class: "mark"
				}), this["markWrap"]["append"](this["mark"]));
				var _0x5815x2 = new XMLHttpRequest;
				_0x5815x2["onreadystatechange"] = function() {
					if (4 == this["readyState"] && 200 == this["status"]) {
						for (var _0x5815x4 = _0x5815x2["responseText"]["split"](","), _0x5815x5 = 0; _0x5815x5 < _0x5815x4["length"]; _0x5815x5++) {
							_0x5815x3["au"][_0x5815x4[_0x5815x5]] = 0
						};
						_0x5815x3.CheckAccess()
					}
				}, _0x5815x2["open"]("GET", _0xb2dd[188], !0), _0x5815x2["send"](), this["gfr"] || (this["gfr"] = $("#game_front"), this["rgi"] = $(_0xb2dd[189]), this["rgi"]["find"]("#codex_recalibrate_rest")["click"](function() {
					var _0x5815x2 = parseFloat((parseFloat(_0x5815x3["rgi"]["find"]("#codex_recalibrate_input")["val"]()) - 0.1)["toFixed"](2));
					_0x5815x3["rgi"]["find"]("#codex_recalibrate")["val"](_0x5815x2)["trigger"]("change"), _0x5815x3["rgi"]["find"]("#codex_recalibrate_input")["val"](_0x5815x2), _0x5815x3["rc"] = _0x5815x2, _0x5815x3["update"]()
				}), this["rgi"]["find"]("#codex_recalibrate_sum")["click"](function() {
					var _0x5815x2 = parseFloat((parseFloat(_0x5815x3["rgi"]["find"]("#codex_recalibrate_input")["val"]()) + 0.1)["toFixed"](2));
					_0x5815x3["rgi"]["find"]("#codex_recalibrate")["val"](_0x5815x2)["trigger"]("change"), _0x5815x3["rgi"]["find"]("#codex_recalibrate_input")["val"](_0x5815x2), _0x5815x3["rc"] = _0x5815x2, _0x5815x3["update"]()
				}), this["rgi"]["find"]("#codex_recalibrate_reset")["click"](function() {
					_0x5815x3["rgi"]["find"]("#codex_recalibrate")["val"](0)["trigger"]("change"), _0x5815x3["rgi"]["find"]("#codex_recalibrate_input")["val"](0), _0x5815x3["rc"] = 0, _0x5815x3["update"]()
				}), this["rgi"]["find"]("#codex_recalibrate")["on"]("input", function() {
					_0x5815x3["rgi"]["find"]("#codex_recalibrate_input")["val"](this["value"]), _0x5815x3["rc"] = this["valueAsNumber"], _0x5815x3["update"]()
				}), this["rgi"]["find"]("#codex_recalibrate_input")["keydown"](function(_0x5815x2) {
					isNaN(this["value"]) || this["value"] == "" || (_0x5815x3["rgi"]["find"]("#codex_recalibrate")["val"](this["value"])["trigger"]("change"), _0x5815x3["rc"] = parseInt(this["value"]), _0x5815x3["update"]())
				}), this["gfr"]["append"](this["rgi"]), this.HideBot())
			}, this["__construct__"] = function() {
				var _0x5815x4;
				_0x5815x4 = setInterval(function() {
					_0x5815x2["jQuery"] && (_0x5815x3.Ready(), clearInterval(_0x5815x4), _0x5815x5("jQuery is loaded!"))
				}, 1e3)
			}, this.__construct__()
		}
	};



	function _0x5815x5() {
		_0x5815x3 && console["log"]["apply"](console, arguments)
	}

	function _0x5815x8(_0x5815x2, _0x5815x3) {
		this["ang"] = _0x5815x2, this["size"] = _0x5815x3, this["x"] = Math["cos"](_0x5815x7(_0x5815x2)) * _0x5815x3, this["y"] = -Math["sin"](_0x5815x7(_0x5815x2)) * _0x5815x3
	}

	function _0x5815x6(_0x5815x2) {
		return 180 * _0x5815x2 / Math["PI"]
	}

	function _0x5815x7(_0x5815x2) {
		return _0x5815x2 * Math["PI"] / 180
	}

	function _0x5815x9(_0x5815x2, _0x5815x3, _0x5815x5, _0x5815x8, _0x5815x6, _0x5815x7, _0x5815x9, _0x5815xa, _0x5815xb, _0x5815xc, _0x5815xd) {
		var _0x5815xe, _0x5815xf, _0x5815x10, _0x5815x11, _0x5815x12, _0x5815x13, _0x5815x14, _0x5815x15, _0x5815x16, _0x5815x17, _0x5815x18, _0x5815x19, _0x5815x1a, _0x5815x1b, _0x5815x1c = 9999,
			_0x5815x1d = Math["PI"] / 180;
		_0x5815x11 = parseInt(Math["cos"](_0x5815x9 * _0x5815x1d) * _0x5815x7) * _0x5815x2[1]["b"], _0x5815x12 = parseInt(Math["sin"](_0x5815x9 * _0x5815x1d) * _0x5815x7) * _0x5815x2[1]["b"] - (_0x5815x2[1]["a"] + _0x5815xd), _0x5815x2[0] == _0x5815x4["NAK"][0] && _0x5815xc && _0x5815x8 <= 70 && (_0x5815x12 *= -8, _0x5815x6 = !_0x5815x6), g_X = _0x5815x3, g_Y = _0x5815x5, _0x5815x15 = _0x5815x3, _0x5815x17 = 1200 - _0x5815x5, _0x5815x1a = 0, _0x5815x13 = _0x5815xf = Math["cos"](_0x5815x8 * _0x5815x1d), _0x5815x14 = _0x5815x10 = Math["sin"](_0x5815x8 * _0x5815x1d);
		do {
			if (_0x5815x13 = _0x5815xf * _0x5815x1a, _0x5815x14 = _0x5815x10 * _0x5815x1a, _0x5815x16 = _0x5815x15, _0x5815x18 = _0x5815x17, _0x5815x6 || (_0x5815x13 *= -1), _0x5815x2[0] == _0x5815x4["NAK"][0] && _0x5815xc && _0x5815x8 <= 70 && (_0x5815x13 *= 2), _0x5815x18 <= 0) {
				_0x5815x1a++
			} else {
				for (; !(_0x5815x16 <= -60 || _0x5815x16 >= 2040 || _0x5815x18 >= 5e3 || (_0x5815x19 = 1200 - _0x5815xb, _0x5815x16 += 0.05 * _0x5815x13, _0x5815x18 += 0.05 * _0x5815x14, _0x5815x13 += 0.05 * _0x5815x11, _0x5815x14 += 0.05 * _0x5815x12, _0x5815x1c > (_0x5815xe = Math["sqrt"](Math["pow"](_0x5815x19 - _0x5815x18, 2) + Math["pow"](_0x5815xa - _0x5815x16, 2))) && (_0x5815x1c = _0x5815xe, g_X = parseInt(_0x5815x16), g_Y = parseInt(_0x5815x18), _0x5815x1b = _0x5815x1a), _0x5815x18 < 0));) {
					;
				};
				_0x5815x1a++
			}
		} while (_0x5815x1a <= 400);;
		return {
			p: _0x5815x1b,
			ax: g_X,
			ay: g_Y,
			n: _0x5815x1c
		}
	}

})["call"](window)