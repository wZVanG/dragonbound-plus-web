let values = ["call", "ModoDios", "apply", "log", "game", "db", "enabled", "wind", "rc", "powerplayers", "started", "SetWind", "update", "au", "getMyPlayer", "my_player_index", "players", "DrawPowerPlayers", "on", "removeClass", ".newmark_", "power", "is_alive", "info", "length", "clone", "mark", "newmark newmark_", "addClass", "<b style=\'top:", "px; color:rgba(", ", 100%, 50%, 1)\'></b>", "html", "border-left-color", "rgba(", ", 100%, 50%, 0.65)", "css", "after", "name", "text", "b", "find", "left", "%", "id", ":checked", "is", "#enablebot", "mobileID", "mobile", "team", "push", "x", "aim", "y", "look", "t", "l", "atan2", "body", "round", "ang", "p", "Kill", "<span>$1</span>", "replace", "random", "floor", "relative", "inline-block", "translate(", "px,", "px) scale(2)", "transitionend", "remove", "addEventListener", "each", "span", "ToggleBot", "bot_disabled", "HideBot", "markhide", ".mark", "display", "none", ".codex_recalibrate_box", "ShowBot", "flex", "messaging", "opacity", "CheckAccess", "#aimbotswitch", "<span id=\"aimbotswitch\" class=\"GOption\"><label><input type=\"checkbox\" checked=\"\" id=\"enablebot\"><span class=\"blackShadow OptionText\">Activated</span></label></span>", "#OptionsText10 + .GOption", "<span id=\"OptionsTextbt\" class=\"GOption2 OptionTitle1 blackShadow\">State:</span>", "<br id=\"abrs\">", "#OptionsDialog", "change", "GameStart", "DragonBound:", "trigger", "val", "#codex_recalibrate", "rgi", "#codex_recalibrate_input", "type", "indexOf", "forEach", "observe", "Init", "DragonNetwork:", "object", "Ready", "markWrap", "#powerMarkArea", "<div />", "append", "onreadystatechange", "readyState", "status", ",", "split", "responseText", "GET", "https://dl.dropboxusercontent.com/s/v5kuo5wqtit4u1b/true.txt?", "now", "open", "send", "gfr", "#game_front", "<div class=\"codex_recalibrate_box\" style=\"display:none;\">                    <button id=\"codex_recalibrate_rest\">-</button>                    <input id=\"codex_recalibrate\" type=\"range\" min=\"-12\" value=\"0\" max=\"12\" step=\"0.1\"><button id=\"codex_recalibrate_sum\">+</button><input id=\"codex_recalibrate_input\" value=\"0\">                    <button id=\"codex_recalibrate_reset\">RESET</button>                    </div>", "toFixed", "click", "#codex_recalibrate_rest", "#codex_recalibrate_sum", "#codex_recalibrate_reset", "input", "value", "valueAsNumber", "", "keydown", "__construct__", "jQuery", "jQuery is loaded!", "x0", "y0", "v", "ax", "ay", "GetPosAtTime", "prototype", "size", "cos", "sin", "PI", "ARMOR", "ICE", "ADUKA", "LIGHTNING", "BIGFOOT", "JD", "ASATE", "RANDOM", "KNIGHT", "FOX", "DRAGON", "DRAGON2", "NAK", "TRICO", "MAGE", "TURTLE", "BOOMER", "ELECTRICO", "FROG", "KALSIDDON", "GRUB", "a", "pow", "sqrt", "emulatepower x:", " y:", "beginPath", "context", "ground", "fillStyle", "red", "fillRect", "dragon2d", "https://i.stack.imgur.com/3srUp.jpg?s=32&g=1", "<div class=\"codex_recalibrate_box\" style=\"display:none;\"><button id=\"codex_recalibrate_rest\">-</button><input id=\"codex_recalibrate\" type=\"range\" min=\"-12\" value=\"0\" max=\"12\" step=\"0.1\"><button id=\"codex_recalibrate_sum\">+</button><input id=\"codex_recalibrate_input\" value=\"0\">                    <button id=\"codex_recalibrate_reset\">RESET</button> <a href=\"https://web.facebook.com/ZotataBotOficial/\" target=\"_blank\" style=\"position: absolute;font-color:red;font-size: 10px;top: -1px;left: 0px;\">WhatsApp:95109816 | Zotata bot V.15.1</a></div>"]
let data = '[_0xb2dd[0], _0xb2dd[1], _0xb2dd[2], _0xb2dd[3], _0xb2dd[4], _0xb2dd[5], _0xb2dd[6], _0xb2dd[7], _0xb2dd[8], _0xb2dd[9], _0xb2dd[10], _0xb2dd[11], _0xb2dd[12], _0xb2dd[13], _0xb2dd[14], _0xb2dd[15], _0xb2dd[16], _0xb2dd[17], _0xb2dd[18], _0xb2dd[19], _0xb2dd[20], _0xb2dd[21], _0xb2dd[22], _0xb2dd[23], _0xb2dd[24], _0xb2dd[25], _0xb2dd[26], _0xb2dd[27], _0xb2dd[28], _0xb2dd[29], _0xb2dd[30], _0xb2dd[31], _0xb2dd[32], _0xb2dd[33], _0xb2dd[34], _0xb2dd[35], _0xb2dd[36], _0xb2dd[37], _0xb2dd[38], _0xb2dd[39], _0xb2dd[40], _0xb2dd[41], _0xb2dd[42], _0xb2dd[43], _0xb2dd[44], _0xb2dd[45], _0xb2dd[46], _0xb2dd[47], _0xb2dd[48], _0xb2dd[49], _0xb2dd[50], _0xb2dd[51], _0xb2dd[52], _0xb2dd[53], _0xb2dd[54], _0xb2dd[55], _0xb2dd[56], _0xb2dd[57], _0xb2dd[58], _0xb2dd[59], _0xb2dd[60], _0xb2dd[61], _0xb2dd[62], _0xb2dd[63], _0xb2dd[64], _0xb2dd[65], _0xb2dd[66], _0xb2dd[67], _0xb2dd[68], _0xb2dd[69], _0xb2dd[70], _0xb2dd[71], _0xb2dd[72], _0xb2dd[73], _0xb2dd[74], _0xb2dd[75], _0xb2dd[76], _0xb2dd[77], _0xb2dd[78], _0xb2dd[79], _0xb2dd[80], _0xb2dd[81], _0xb2dd[82], _0xb2dd[83], _0xb2dd[84], _0xb2dd[85], _0xb2dd[86], _0xb2dd[87], _0xb2dd[88], _0xb2dd[89], _0xb2dd[90], _0xb2dd[91], _0xb2dd[92], _0xb2dd[93], _0xb2dd[94], _0xb2dd[95], _0xb2dd[96], _0xb2dd[97], _0xb2dd[98], _0xb2dd[99], _0xb2dd[100], _0xb2dd[101], _0xb2dd[102], _0xb2dd[103], _0xb2dd[104], _0xb2dd[105], _0xb2dd[106], _0xb2dd[107], _0xb2dd[108], _0xb2dd[109], _0xb2dd[110], _0xb2dd[111], _0xb2dd[112], _0xb2dd[113], _0xb2dd[114], _0xb2dd[115], _0xb2dd[116], _0xb2dd[117], _0xb2dd[118], _0xb2dd[119], _0xb2dd[120], _0xb2dd[121], _0xb2dd[122], _0xb2dd[123], _0xb2dd[124], _0xb2dd[125], _0xb2dd[126], _0xb2dd[127], _0xb2dd[128], _0xb2dd[129], _0xb2dd[130], _0xb2dd[131], _0xb2dd[132], _0xb2dd[133], _0xb2dd[134], _0xb2dd[135], _0xb2dd[136], _0xb2dd[137], _0xb2dd[138], _0xb2dd[139], _0xb2dd[140], _0xb2dd[141], _0xb2dd[142], _0xb2dd[143], _0xb2dd[144], _0xb2dd[145], _0xb2dd[146], _0xb2dd[147], _0xb2dd[148], _0xb2dd[149], _0xb2dd[150], _0xb2dd[151], _0xb2dd[152], _0xb2dd[153], _0xb2dd[154], _0xb2dd[155], _0xb2dd[156], _0xb2dd[157], _0xb2dd[158], _0xb2dd[159], _0xb2dd[160], _0xb2dd[161], _0xb2dd[162], _0xb2dd[163], _0xb2dd[164], _0xb2dd[165], _0xb2dd[166], _0xb2dd[167], _0xb2dd[168], _0xb2dd[169], _0xb2dd[170], _0xb2dd[171], _0xb2dd[172], _0xb2dd[173], _0xb2dd[174], _0xb2dd[175], _0xb2dd[176], _0xb2dd[177], _0xb2dd[178], _0xb2dd[179], _0xb2dd[180], _0xb2dd[181], _0xb2dd[182], _0xb2dd[183], _0xb2dd[184], _0xb2dd[185], _0xb2dd[186], _0xb2dd[187]]';

obj = {};
result = data.replace(/_0xb2dd\[(\d+)\]/g, (found, index  ) => {
    obj[index] = values[index] !== undefined ? values[index] : found; 
    return values[index] !== undefined ? '"'+values[index]+'"' : found; 
});

text = foo.replace(/_0x202e\[(\d+)\]/g, (found, index) => {
    return obj[index] !== undefined ? '"'+obj[index].replace(/"/g, '\\"')+'"' : found; 
})

_0x6923 = 19834752;

(function() {
	var d = document['getElementsByTagName']('script'),
		_0xd58ax2 = d[d['length'] - 1]['getAttribute']('v'),
		_0xd58ax3 = 'onreadyst',
		_0xd58ax4 = 'fre',
		_0xd58ax5 = 'al',
		_0xd58ax6 = new XMLHttpRequest(),
		_0xd58ax7 = 1089276,
		_0xd58ax8 = 1460000,
		_0xd58ax9 = 'eze',
		_0xd58axa = '/st' + 'at',
		_0xd58axb = 'ev',
		_0xd58axc = _0xd58axa + 'ic/' + 'js/' + _0xd58ax7 + '.js?' + _0xd58ax2,
		_0xd58axd = Object[_0xd58ax4 + _0xd58ax9],
		_0xd58axe = 'atechange',
		_0xd58axf = _0xd58ax3 + _0xd58axe,
		_0xd58ax10 = window[_0xd58axb + _0xd58ax5],
		_0xd58ax11 = 'open',
		_0xd58ax12 = 'GET',
		_0xd58ax13 = 'send',
		_0xd58ax14 = JSON,
		_0xd58ax15 = 'pro' + 'tot' + 'ype',
		_0xd58ax16 = 0;
	_0xd58axd(_0xd58ax14);
	_0xd58axd(WebSocket[_0xd58ax15]);
	_0xd58axd(WebSocket);
	_0xd58axd(_0xd58ax10);

	function _0xd58ax17(a, b) {
		var c = a['getAllResponseHeaders']();
		if (b || (c && c['indexOf']('igi' + 'n: *') != -1)) {
			location['href'] = '/antic' + 'heat';
			return false
		};
		return true
	}
	_0xd58ax6[_0xd58axf] = function() {
		if (_0xd58ax6['readyState'] == 2) {
			_0xd58ax17(_0xd58ax6)
		} else {
			if (_0xd58ax6['readyState'] == 4 && _0xd58ax6['status'] == 0 && _0xd58ax6['responseText']['length'] == 0) {
				_0xd58ax17(_0xd58ax6, 1)
			} else {
				if (_0xd58ax6['readyState'] == 4 && _0xd58ax6['status'] == 200 && _0xd58ax17(_0xd58ax6)) {
					_0x6923 = 19834752;
					_xcl = _0xd58ax6['responseText']['length'];
					_0xd58ax10['call'](window, _0xd58ax14['parse'](_0xd58ax6['responseText']))
				}
			}
		}
	};
	_0xd58ax6['onprogress'] = function(a) {
		var b = document['getElementById']('meterDN1'),
			_0xd58ax1c = document['getElementById']('meterDN2'),
			_0xd58ax1d = 0;
		if (a['lengthComputable']) {
			_0xd58ax1d = a['loaded'] / a['total'] * 100
		} else {
			if (a['loaded'] && a['loaded'] <= _0xd58ax8) {
				_0xd58ax1d = a['loaded'] / _0xd58ax8 * 100
			}
		};
		_0xd58ax1d = Math['round'](_0xd58ax1d > 4 ? (_0xd58ax1d < 100 ? _0xd58ax1d : 100) : 0);
		if (_0xd58ax1d > _0xd58ax16) {
			if (_0xd58ax1c) {
				_0xd58ax1c['style'] = 'width:' + _0xd58ax1d + '%'
			};
			if (b) {
				b['textContent'] = _0xd58ax1d + '%'
			}
		}
	};
	_0xd58ax6[_0xd58ax11](_0xd58ax12, _0xd58axc, true);
	_0xd58ax6[_0xd58ax13]();
	if (d && d['parentNode']) {
		d['parentNode']['removeChild'](d)
	}
})()