var GLOBALS = {};

GLOBALS.URL_HELPER = "helper.html";
GLOBALS.EXT_DETAILS = chrome.app.getDetails();
//GLOBALS.PAGE_URL = /\/([^\/]+)\/?/.exec(GLOBALS.EXT_DETAILS.homepage_url)[1];
GLOBALS.PAGE_URL = "www.dragonbound.plus";

GLOBALS.ASSETS_DIR = "http://dragonbound.plus/helper/";

GLOBALS.GAME = {};
GLOBALS.GAME.FRONTWIDTH = 800;
GLOBALS.GAME.FRONTHEIGHT = 600;